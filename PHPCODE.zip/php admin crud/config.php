<?php

$conn = mysqli_connect('localhost','root','','cart_db',3306) or die(" connection failed !");

?>