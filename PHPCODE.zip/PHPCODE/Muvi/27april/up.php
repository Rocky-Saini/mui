<?php
$file = $_FILES[]
 move_uploaded_file($_FILES['f']['tmp_name'], $_FILES['f']['name']);

 echo "success"; 
?>