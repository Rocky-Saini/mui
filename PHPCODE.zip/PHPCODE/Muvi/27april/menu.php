<h2>Test Links with extensions</h2>
<a href="index.php">Index</a>
<a href="about.php">About</a>


<h2>Test Links with OUt extensions</h2>
<a href="index">Index</a>
<a href="about">About</a>

