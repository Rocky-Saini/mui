<!-- <form action="up.php" enctype="multipart/form-data" method="post">
	<input type="file" name="f" />
	<br />
    <br/>
	<input type="submit" name="btn" value= "upload" />
	 


</form> -->

<!-- <?php
$_ENV['USERNAME']=getenv('USERNAME');
$_ENV['OS']=getenv('OS');
echo "User Name"

?> -->

<!-- <?php
if(strpos($_SERVER["HTTP_USER_AGENT"],"Chrome"))
echo "<h1>" . "You are using chrome". "</h1>";
else
echo "unknown browser";

?> -->

<!-- <?php
echo $_SERVER['SERVER_NAME']."<br/>";

echo $_SERVER['DOCUMENT_ROOT']."<br/>";

echo $_SERVER['SERVER_PROTOCOL']."<br/>"; echo $_SERVER['SERVER_SOFTWARE']."<br/>";

if(strpos($_SERVER["HTTP_USER_AGENT"],"Chrome")) echo "<h1>". "You're using Chrome"."</h1>";

else

echo "Unknown Browser";


?> -->




<?php
  include 'menu.php';   
?>
Wel come to our website !

























