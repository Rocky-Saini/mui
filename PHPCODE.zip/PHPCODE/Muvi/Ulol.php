<!-- Unordered Lists -->
<ul>
    <li>Rocky Saini</li>
    <li>Black Forest Cake</li>
    <li>Pineapple Cake</li>
</ul>

<!-- Ordered List -->
<ol>
    <li>Rocky Saini</li>
    <li>Starts the car</li>
    <li>Look around and go</li>
</ol>