<!-- Alias of current  -->
<?php
$people= array("Peter","Joe","Glenn","Cleveland");
echo pos($people)."</br />";

?>

