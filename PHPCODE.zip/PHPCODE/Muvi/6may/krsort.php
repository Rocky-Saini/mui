<!-- Sorts an array by key in reverse order -->

<?php
 $my_array=array("a"=>"Dog","b"=>"Cat","c"=>"Horse");

 krsort($my_array);
 print_r($my_array);
 
?>