

<?php
$people= array("Peter","Joe","Glenn","Cleveland");
$result = count($people);
echo $result;
?>