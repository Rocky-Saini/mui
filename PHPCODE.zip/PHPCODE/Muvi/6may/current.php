<?php
$people= array("Peter","Joe","Glenn","Cleveland");
echo current($people)."<br/>";
?>