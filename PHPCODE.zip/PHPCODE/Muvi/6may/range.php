<!-- Create an conating=ing range  -->
<?php
$number = range(0,5);
print_r($number);

?>