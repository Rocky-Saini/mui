<?php
$people= array("Peter","Joe","Glenn","Cleveland");
print_r(each($people));

?>