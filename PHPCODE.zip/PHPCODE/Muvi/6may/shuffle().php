<?php
 $my_array= array("a"=>"Dog","b"=>"Cat","c"=>"Horse");
 shuffle($my_array);
 print_r($my_array);

?>