<!-- Rewinds the internal array pointer  -->

<?php
$people= array("Peter","Joe","Glenn","Cleveland");
echo current($people)."</br />";
echo next($people). "<br />";
echo prev($people);

?>