<?php
$people = array("Peter", "Joe", "Glenn", "Cleveland");
echo "The key from the current position is: " . key($people);
?>