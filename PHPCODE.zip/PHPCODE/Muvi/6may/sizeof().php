<?php
 $people= array("Peter","Joe","Glenn","Cleveland");
 $result = sizeof($people);
 echo $result;

?>