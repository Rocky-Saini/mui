<?php
 $my_array= array("a"=>"Dog","b"=>"Cat","c"=>"Horse");
 rsort($my_array);
 print_r($my_array);

?>
