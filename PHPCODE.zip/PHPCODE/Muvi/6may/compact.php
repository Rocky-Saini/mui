<?php
$firstname = "Peter";
$lastname="Griffin";
$age = "38";
$result = compact("firstname","lastname","age");
print_r($result);


?>
