<!-- Assigns varibales as if they were an array  -->
<?php

$my_array = array("Dog","Cat","Horse");
list($a,$b,$c)=$my_array;
echo "I have several animals, a $a , a $b and a $c.";

?>