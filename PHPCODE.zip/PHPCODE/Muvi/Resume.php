<link rel="stylesheet" href="stylee.css">
<div id="header"></div>
<div class="left"></div>
<div class="stuff">
  <br><br>
  <h1>Resume</h1>
  <h2>Rocky Saini</h2>
  <hr />
  <br>
  <p class="head">Interests</p>
  <ul>
    <li>Drawing</li>
    <li>Photography</li>
    <li>Design</li>
    <li>Programming</li>
    <li>Computer Science</li>
  </ul>
  <p class="head">Skills</p>
  <ul>
    <li>Web Design with HTML & CSS</li>
  </ul>
  <p class="head">Education</p>
  <ul>
    <a href="https://www.shobhitUniversity.com">
      <li>Shobhit University</li>
    </a>
    <a href="https://www.shobhitUniversity.com">
      <li>Shobhit University</li>
    </a>
    <li>CodeSeFod</li>
  </ul>
  <p class="head">Experience</p>
  <ul>
    <li>Associate Sofware engineer Muvi.com</li>
    <li>FullStack</li>
  </ul>
  <p class="head">Extracurriculars</p>
  <ul>
    <li>Recycling Club</li>
    <li>Gardening Club</li>
    <li>Book Club</li>
  </ul>
</div>
<div class="right"></div>
<div id="footer">
  <h2 id="name">Rocky Saini</h2></div>