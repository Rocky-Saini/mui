<!-- <?php
   class Demo{
       public $i=10;
   }
   $obj = new Demo();

   echo $obj->i;


?> -->

<?php
     $i=10;
     $i=null;
     echo $i;  // null


?>