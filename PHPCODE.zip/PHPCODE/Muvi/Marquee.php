<!DOCTYPE html>
<html>
   <head>
      <title>HTML Marquee Tag</title>
   </head>
	   <body>
      <marquee>This is basic example of marquee</marquee>
   </body>
	</html>