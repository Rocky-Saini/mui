<link rel="stylesheet" href="style.css">

<div class="loginbox">
    <img src="Images/icon.png" class="users">
    <h1>Login here!</h1>
    <input type="text" name="userid" placeholder="User id"><br>
    <input type="password" name="password" placeholder="Password"><br>
    <input type="submit" name="submit" placeholder="Submit">
</div>