<p>
  <a href="http://www.codesefod.com/" 
     style="text-decoration: none">Codesefod IT Solutions</a>
</p>