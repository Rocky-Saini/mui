<?php
 echo date("Y-m-d");
 echo "<br />";
 echo date("Y/m/d");
 echo "<br />";
 echo date("M d, Y");
 echo "<br />";
 echo date("F d, Y");
 echo "<br />";
 echo date("D M d, Y");
 echo "<br />";
 echo date("D M d Y");
 echo "<br />";
 echo date("I F d Y");
 echo "<br />";
 echo date("I F d Y,h:i:s");
 echo "<br />";
 echo date("I F d Y,h:i A");


?>