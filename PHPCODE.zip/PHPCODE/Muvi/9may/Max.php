<?php
define("Greeting","Hello rocky");

function show()
{
    echo Greeting;
}
show();
?>