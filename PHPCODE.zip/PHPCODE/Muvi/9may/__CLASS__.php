<?php

class Demo {
    function show()
    {
        echo __CLASS__;
    }
}
$obj = new Demo();
$obj->show();
?>