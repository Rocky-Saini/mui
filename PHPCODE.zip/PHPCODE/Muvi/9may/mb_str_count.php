<?php
echo mb_substr_count("This is a test","is"); //prints out 2

?>