<?php

echo __LINE__;

?>