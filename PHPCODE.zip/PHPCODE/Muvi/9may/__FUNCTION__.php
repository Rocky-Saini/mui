<?php
  function show()
  {
      echo __FUNCTION__;
  }


?>