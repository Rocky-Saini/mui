<?php
echo mysqli_get_client_version();

?>