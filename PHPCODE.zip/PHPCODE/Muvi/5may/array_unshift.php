 <!-- add one more elemet to the beginngg of the arra/y -->
<?php
$a=array("a"=>"Cat","b"=>"Dog");
array_unshift($a,"Horse");
print_r($a);
?>