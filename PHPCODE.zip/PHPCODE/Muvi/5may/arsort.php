<!-- sort an array in reverse order and maintain index association   -->
<?php
$my_array = array("a"=>"Dog","b"=>"Cat","c"=>"Horse");

arsort($my_array);
print_r($my_array);

?>