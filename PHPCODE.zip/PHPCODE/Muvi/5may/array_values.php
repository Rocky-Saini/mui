<!-- Returns all the value of the array   -->
<?php
 $a = array("a"=>"Cat","b"=>"Dog","c"=>"Horse");
 print_r(array_values($a));

?>