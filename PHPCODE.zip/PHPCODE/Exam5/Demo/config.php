<?php
$con=mysqli_connect('localhost','root','','example_ecomm_one',3301) or die('conn failed...');

?>