<?php
$con=mysqli_connect('localhost','root','','data',3301) or die('conn failed...');

?>
