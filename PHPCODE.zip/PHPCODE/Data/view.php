<!DOCTYPE html>
<html>
<head>

<title>Untitled Document</title>
</head>

<body>

<h1 style="text-align:center; color:#CC3300;" > Welcome to the home page.</h1>
</body>
</html>