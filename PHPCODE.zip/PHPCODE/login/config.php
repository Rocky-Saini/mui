<?php

$conn = mysqli_connect('localhost','root','','NEWW',3301) or die("Connection Failed;");

?>