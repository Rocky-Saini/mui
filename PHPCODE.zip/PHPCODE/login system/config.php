<?php

$conn = mysqli_connect('localhost','root','','user_db',3301) or die("Connection Failed;");

?>