<?php
$con=mysqli_connect('localhost','root','','example_ecomm_one',3306) or die('conn failed...');

?>