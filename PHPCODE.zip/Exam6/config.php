<?php

$conn = mysqli_connect('localhost','root','','order',3306) or die(" connection failed !");

?>