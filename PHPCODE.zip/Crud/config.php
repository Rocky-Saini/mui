<?php

$conn = mysqli_connect('localhost','root','','example_ecomm_one',3306) or die(" connection failed !");

?>