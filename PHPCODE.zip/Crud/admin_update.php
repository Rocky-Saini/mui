<?php

@include 'config.php';

$OrderID = $_GET['edit'];

if(isset($_POST['update_product'])){

   $ProdID = $_POST['ProdID'];
   $ProdRate = $_POST['ProdRate'];
   $OrderValue = $_POST['OrderValue'];
 

   if(empty($ProdID) || empty($ProdRate) || empty($OrderValue)){
      $message[] = 'please fill out all!';    
   }else{

      $update_data = "UPDATE order_master SET ProdID='$ProdID', ProdRate='$ProdRate', OrderValue='$OrderValue'  WHERE  OrderID = '$OrderID'";
      $upload = mysqli_query($conn, $update_data);

      if($upload){
         // move_uploaded_file($product_image_tmp_name, $product_image_folder);
         header('location:admin_page.php');
      }else{
         $$message[] = 'please fill out all!'; 
      }

   }
};

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="css/style.css">
</head>
<body>

<?php
   if(isset($message)){
      foreach($message as $message){
         echo '<span class="message">'.$message.'</span>';
      }
   }
?>

<div class="container">


<div class="admin-product-form-container centered">

   <?php
      
      $select = mysqli_query($conn, "SELECT * FROM order_master WHERE OrderID = '$OrderID'");
      while($row = mysqli_fetch_assoc($select)){

   ?>
   
   <form action="" method="post" enctype="multipart/form-data">
      <h3 class="title">update the product</h3>
      <input type="text" class="box" name="ProdID" value="<?php echo $row['ProdID']; ?>" placeholder="enter the product name">
      <input type="number" min="0" class="box" name="ProdRate" value="<?php echo $row['ProdRate']; ?>" placeholder="enter the product price">
      <input type="number" min="0" class="box" name="OrderValue" value="<?php echo $row['OrderValue']; ?>" placeholder="enter the product price">
  
      <input type="submit" value="update product" name="update_product" class="btn">
      <a href="admin_page.php" class="btn">go back!</a>
   </form>
   


   <?php }; ?>

   

</div>

</div>

</body>
</html>