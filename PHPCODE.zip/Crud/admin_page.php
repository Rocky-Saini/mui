<?php
@include 'config.php';

if(isset($_POST['add_product'])){

@$ProdID=$_REQUEST['ProdID']; 
@$ProdName=$_REQUEST['ProdName'];
@$ProdQty=$_REQUEST['ProdQty'];
@$ProdRate=$_REQUEST['ProdRate'];
@$ProdValue=(int)$ProdQty*(int)$ProdRate;
@$date=date('dd/mm/yyyy');
include_once 'config.php';
   if(empty($product_name) || empty($product_price) || empty($product_image)){
      $message[] = 'please fill out all';
   }else{
      $insert = "INSERT INTO order_master (OrderDate, ProdID, ProdRate, OrderQty, OrderValue)
        VALUES ('$date', '$ProdID', '$ProdRate', '$ProdQty', '$ProdValue')";
      $upload = mysqli_query($conn,$insert);
      if($upload){
         $message[] = 'new product added successfully';
      }else{
         $message[] = 'could not add the product';
      }
   }

};

// @$ProdID=$_REQUEST['ProdID']; 
// @$ProdName=$_REQUEST['ProdName'];
// @$ProdQty=$_REQUEST['ProdQty'];
// @$ProdRate=$_REQUEST['ProdRate'];
// @$ProdValue=(int)$ProdQty*(int)$ProdRate;
// @$date=date('dd/mm/yyyy');
// include_once 'config.php';

// $sql="INSERT INTO order_master (OrderDate, ProdID, ProdRate, OrderQty, OrderValue)
//  VALUES ('$date', '$ProdID', '$ProdRate', '$ProdQty', '$ProdValue')";
// mysqli_query($conn,$sql);
// if(mysqli_affected_rows($conn)>0) {
//      echo "save success !";
// } else{
// echo "some error!";
// }
if(isset($_GET['delete'])){
   $OrderID = $_GET['delete'];
   mysqli_query($conn, "DELETE FROM order_master WHERE OrderID = $OrderID");
   header('location:admin_page.php');
};
?>
<!-- <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk="
    crossorigin="anonymous"></script>
<script type="text/javascript">
      $(document).ready(function(){
            $("#ProdName").blur(function()
            {
                        var errorProdQty = true;
                        function validProdQty(){
                            ProdQty = parseInt($('#ProdQty').val());
                            ProdQtyOld = parseInt($('#ProdQtyOld').val());
                            if (ProdQtyOld >= ProdQty) {
                                errorProdQty = true;
                            } else {
                                errorProdQty = false;
                            }
                        }
                        $("#btn").click(function(){
                            validProdQty();
                            if (errorProdQty) {
                                return true;
                            } else {
                                return false;
                            }
                        })
                        $.ajax({
                            type: "POST",
                            url: "getproductname.php",
                            dataType: "JSON",
                            data: {ProdName:$("#ProdName").val()},
                            success:function(res){
                                if (res) {
                                    $("#errorProductName").html("&#x2611;");
                                    $("#ProdRate").val(res.ProdRate);
                                    $("#ProdQtyOld").val(res.ProdQty);
                                    $("#ProdID").val(res.ProdID);
                                    $("#ProdRate").val(res.ProdRate);
                                    $("#btn").attr("disabled", false);
                                } else {
                                    $("#errorProductName").html("product not aval !");
                                    $("#ProdRate").val("");
                                    $("#ProdQtyOld").val("");
                                    $("#ProdID").val("");
                                    $("#ProdRate").val("");
                                    $("#btn").attr("disabled", true);
                                }
                            }
             })

        })

})
</script>

<form method="get" action="save.php">
    Product Name : <input type="text" name="ProdName" id="ProdName" /> <span id="errorProductName"></span>
    <br />
    Product rate : <input type="text" name="ProdRate" readonly id="ProdRate" />
    <br />
    Product Qty: <input type="text" name="ProdQty" id="ProdQty" />
    <input type="text" style="display: none;" name="ProdQtyOld" id="ProdQtyOld" /> 
    <input type="text" style="display: none;" name="ProdID" id="ProdID" />
    <input type="text" style="display: none;" name="ProdRate" id="ProdRate" />
    <br />
    <input type="submit" value="save" id="btn" disabled />
</form> -->
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>admin page</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">
   <script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk="
    crossorigin="anonymous"></script>
<script type="text/javascript">
      $(document).ready(function(){
            $("#ProdName").blur(function()
            {
                        var errorProdQty = true;
                        function validProdQty(){
                            ProdQty = parseInt($('#ProdQty').val());
                            ProdQtyOld = parseInt($('#ProdQtyOld').val());
                            if (ProdQtyOld >= ProdQty) {
                                errorProdQty = true;
                            } else {
                                errorProdQty = false;
                            }
                        }
                        $("#btn").click(function(){
                            validProdQty();
                            if (errorProdQty) {
                                return true;
                            } else {
                                return false;
                            }
                        })
                        $.ajax({
                            type: "POST",
                            url: "getproductname.php",
                            dataType: "JSON",
                            data: {ProdName:$("#ProdName").val()},
                            success:function(res){
                                if (res) {
                                    $("#errorProductName").html("&#x2611;");
                                    $("#ProdRate").val(res.ProdRate);
                                    $("#ProdQtyOld").val(res.ProdQty);
                                    $("#ProdID").val(res.ProdID);
                                    $("#ProdRate").val(res.ProdRate);
                                    $("#btn").attr("disabled", false);
                                } else {
                                    $("#errorProductName").html("product not aval !");
                                    $("#ProdRate").val("");
                                    $("#ProdQtyOld").val("");
                                    $("#ProdID").val("");
                                    $("#ProdRate").val("");
                                    $("#btn").attr("disabled", true);
                                }
                            }
             })

        })

})

$("#form").validate({
    rule:{
        ProdName:{
           ProdName:true
        },
        messages:{
         required:'please enter product name'
        }
    }
    
   });
</script>
</head>
<body>
<div class="container">

   <div class="admin-product-form-container">
   <form id="form" action="<?php $_SERVER['PHP_SELF'] ?>" method="get" enctype="multipart/form-data" >
   <h3>add a new product</h3>
   Product Name : <input type="text" class="box" name="ProdName" id="ProdName" required/> <span id="errorProductName"></span>
    <br />
    Product rate : <input type="text" class="box" name="ProdRate" readonly id="ProdRate" required />
    <br />
    Product Qty: <input type="text" class="box" name="ProdQty" id="ProdQty"  required/>
    <input type="text" style="display: none;" name="ProdQtyOld" id="ProdQtyOld" /> 
    <input type="text" style="display: none;" name="ProdID" id="ProdID" />
    <input type="text" style="display: none;" name="ProdRate" id="ProdRate" />
    <br />
    <input type="submit" class="btn" value="save" name="add_product" id="btn" disabled />
    <input type="submit" class="btn" value="reset"   />
</form> 
   </div>
</div>




<?php

   $select = mysqli_query($conn, "SELECT * FROM order_master");
   
   ?>
   <div class="product-display">
      <table class="product-display-table">
         <thead>
         <tr>
            <th>product id</th>
            <th>product rate</th>
            <th>Order Date</th>
            <th>Order Qty</th>
            <th>product Value</th>
            <th>action</th>
         </tr>
         </thead>
         <?php while($row = mysqli_fetch_assoc($select)){ ?>
         <tr>
            <td><?php echo $row['ProdID']; ?></td>
            <td><?php echo $row['ProdRate']; ?></td>
            <td><?php echo $row['OrderDate']; ?></td>
            <td><?php echo $row['OrderQty']; ?></td>
            <td>Rupees<?php echo $row['OrderValue']; ?>/-</td>
            <td>
               <a href="admin_update.php?edit=<?php echo $row['OrderID']; ?>" class="btn"> <i class="fas fa-edit"></i> edit </a>
               <a href="admin_page.php?delete=<?php echo $row['OrderID']; ?>" class="btn"> <i class="fas fa-trash"></i> delete </a>
            </td>
         </tr>
      <?php } ?>
      </table>
   </div>

</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.3/jquery.validate.min.js"></script>

<script src="./main.js"></script>
</body>
</html>